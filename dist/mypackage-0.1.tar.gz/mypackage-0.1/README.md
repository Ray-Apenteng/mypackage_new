# mypackage_new
This is a package created while practicing how to build python packages for myself

# How to install
....